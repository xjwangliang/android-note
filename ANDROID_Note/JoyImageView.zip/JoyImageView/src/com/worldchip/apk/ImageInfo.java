package com.worldchip.apk;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import android.graphics.Bitmap;

public class ImageInfo {

	public int id;
	public Bitmap icon;
	public String displayName;  
	public String path;
	public String picturecount;
	public List tag;
}
