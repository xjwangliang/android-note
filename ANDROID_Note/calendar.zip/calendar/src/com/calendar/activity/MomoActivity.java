package com.calendar.activity;

import android.app.Activity;
import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.LinearLayout.LayoutParams;

import com.calendar.sqlite.CalendarColumns;
import com.calendar.sqlite.CalendarColumns.CalendarColumn;

public class MomoActivity extends Activity {
	private static String date;
	
	public static final String[] PROJECTION = new String[]{
		CalendarColumn._ID,
		CalendarColumn.CONTENT,
		CalendarColumn.CREATED,
		CalendarColumn.DATE,
		CalendarColumn.TIME,
		CalendarColumn.ISORUSE,
		CalendarColumn.ISORREVEAL
		
	}; 
	private SimpleCursorAdapter adapter;
	
	private LinearLayout linearLayout ;
	
	private ListView listView;
	
	private int listViewItemId ;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		final Intent intent = getIntent();
		if(null == intent.getData()){
			intent.setData(CalendarColumn.CONTENT_URI);
		}
		
		listView = (ListView)findViewById(R.id.itemlist);
		date = intent.getStringExtra("curDate");
		linearLayout = new LinearLayout(this);
		linearLayout.setOrientation(LinearLayout.HORIZONTAL);
		initDate();
		
		listView.setOnItemClickListener(new OnItemClickListener(){

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				listViewItemId = (int)arg3;
				openOptionsMenu();
			}
			
		});
		
		
		this.addContentView(linearLayout, new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
		
	}
	
	/**
	 * ������Դ
	 */
	 public void initDate(){
		
		 getIntent().setData(CalendarColumn.CONTENT_URI);
		
		 Cursor cursor = this.managedQuery(this.getIntent().getData(), PROJECTION, "date=?", new String[]{date}, CalendarColumn.DEFAULT_SORT_ORDER);
		 int count = cursor.getCount();
		 if(null != cursor && 0!=count){
		     adapter = new SimpleCursorAdapter(this,android.R.layout.simple_expandable_list_item_2,cursor,new String[]{CalendarColumn._ID,CalendarColumn.CONTENT},new int[]{android.R.id.text1,android.R.id.text2});
		     listView.setAdapter(adapter);
		     //generateChoose(linearLayout,"ѡ��");
		 }else{
			 Toast toast=Toast.makeText(this, "����û�����ý���ı���¼��", Toast.LENGTH_LONG);
			 toast.setGravity(Gravity.TOP|Gravity.CENTER, 0, 40);
			 toast.show();
			 generateChoose(linearLayout,"����");
		 }
	 }
	 
	 /**
		 * ѡ��ѡ��
		 * @param layChoose
		 */
		private void generateChoose(LinearLayout layChoose,String btnOkText) {
			
			layChoose.setPadding(8, 377, 0, 0);
			final Button btnOk = new Button(this);
			btnOk.setText(btnOkText);
			btnOk.setWidth(80);
			btnOk.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
			
			
			btnOk.setOnClickListener(new OnClickListener(){
				public void onClick(View v) {
					intentStart("2");
				}
			});
			
			
			Button btnCel = new Button(this);
			btnCel.setText("����");
			btnCel.setWidth(79);
			btnCel.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
			
			btnCel.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View v) {
					Intent intent = new Intent(MomoActivity.this,CalendarActivity.class);
					startActivity(intent);
				}
				
			});
			
			TextView textView = new TextView(this);
			textView.setWidth(145);
			
			layChoose.addView(btnOk);
			layChoose.addView(textView);
			layChoose.addView(btnCel);
		}
		/**
		 * ��תҳ��
		 */
		private void intentStart(String b){
			Bundle bundle = new Bundle();
			bundle.putString("b", b);
			bundle.putInt("id", listViewItemId);
			bundle.putString("date", date);
			Intent intent = new Intent(MomoActivity.this,CalendarDetailsActivity.class);
			intent.putExtra("bundle",bundle);
			startActivity(intent);
		}
		
	
	private void delOption(boolean bool){
		if(bool){
			Uri uri = ContentUris.withAppendedId(CalendarColumns.CalendarColumn.CONTENT_URI, listViewItemId);
			this.getContentResolver().delete(uri, null, null);
		}else{
			
			this.getContentResolver().delete(CalendarColumns.CalendarColumn.CONTENT_URI, "date=?", new String[]{date});
		}
		
		initDate();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		menu.add(1,1,0,"�鿴");
		menu.add(2,2,0,"����");
		menu.add(3,3,0,"�༭");
		menu.add(4,4,0,"ɾ��");
		menu.add(5,5,0,"ȫ��ɾ��");
		menu.add(6,6,0,"����");
		
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public void openOptionsMenu() {
		super.openOptionsMenu();
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch(item.getItemId()){
		case 1:
			intentStart("1");
			break;
		case 2:
			intentStart("2");
			break;
		case 3:
			intentStart("1");
			break;
		case 4:
			delOption(true);
			break;
		case 5:
			delOption(false);
			break;
		case 6:
			closeOptionsMenu();
			Intent intent = new Intent(MomoActivity.this,CalendarActivity.class);
			startActivity(intent);
			break;
		}
		return super.onContextItemSelected(item);
	}

	@Override
	public void closeOptionsMenu() {
		super.closeOptionsMenu();
	}
	
	
		
	 
}
