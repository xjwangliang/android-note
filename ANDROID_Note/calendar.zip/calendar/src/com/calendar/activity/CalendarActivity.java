package com.calendar.activity;

import java.util.ArrayList;
import java.util.Calendar;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import com.calendar.draw.DateWidgetDayCell;
import com.calendar.draw.DateWidgetDayHeader;
import com.calendar.draw.DayStyle;
import com.calendar.draw.SymbolButton;

public class CalendarActivity extends Activity {
	//������ʾ����
	private ArrayList<DateWidgetDayCell> days = new ArrayList<DateWidgetDayCell>();
	//��ʾ��ʼ������
	private Calendar calStartDate = Calendar.getInstance();
	//��ʾ���������
	private Calendar calToday = Calendar.getInstance();
	//��ʾ���ص�������
	private Calendar calCalendar = Calendar.getInstance();
	//ѡ�������
	private Calendar calSelected = Calendar.getInstance();
	//����
	LinearLayout layContent = null;
	//��һ�갴ť
	Button btnYearPrev = null;
	//���갴ť
	Button btnYearToday = null;
	//���갴ť
	Button btnYearNext = null;
	
	//�ϸ��°�ť
	Button btnMonthPrev = null;
	//���°�ť
	Button btnMonthToday = null;
	//�¸��°�ť
	Button btnMonthNext = null;
	//һ�ܵ�һ��
	private int iFirstDayOfWeek = Calendar.MONDAY;
	//��ǰ��
	private int iMonthViewCurrentMonth = 0;
	//��ǰ��
	private int iMonthViewCurrentYear = 0;
	//��ʾ����
	private TextView tv;

	@Override
	public void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		
		//��ý�������ڼ�
		iFirstDayOfWeek = Calendar.MONDAY;
		//����
		setContentView(generateContentView());
		//��ʼ����
		calStartDate = getCalendarStartDate();
		DateWidgetDayCell daySelected = updateCalendar();
		if (daySelected != null)
			daySelected.requestFocus();
	}

	@Override
	public void onStart() {
		super.onStart();

	}

	/**
	 * ���ݴ������Ĳ��ַ��������ò���
	 * @param iOrientation Ҫ���ֵķ���
	 * @return ����һ������
	 */
	private LinearLayout createLayout(int iOrientation) {
		LinearLayout lay = new LinearLayout(this);
		
		lay.setLayoutParams(new LayoutParams(
				android.view.ViewGroup.LayoutParams.FILL_PARENT,
				android.view.ViewGroup.LayoutParams.WRAP_CONTENT));
		
		lay.setOrientation(iOrientation);
		return lay;
	}

	/**
	 * ����button��ť
	 * @param sText  ��ť��ʾ����
	 * @param iWidth  ��ť�Ŀ���
	 * @param iHeight  ��ť�ĸ߶�
	 * @return ���ذ�ť
	 */
	private Button createButton(String sText, int iWidth, int iHeight) {
		Button btn = new Button(this);
		btn.setText(sText);
		btn.setLayoutParams(new LayoutParams(iWidth, iHeight));
		return btn;
	}

	/**
	 * ����ͷ����ť
	 * @param layTopControls
	 */
	private void generateTopButtons(LinearLayout layTopControls) {
		final int iHorPadding = 24;
		final int iSmallButtonWidth = 50;
		//�����м�ĵ������ڰ�ť
		btnYearToday = createButton("",iSmallButtonWidth,
				android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
		btnYearToday.setPadding(iHorPadding, btnYearToday.getPaddingTop(), iHorPadding,
				btnYearToday.getPaddingBottom());
		btnYearToday.setBackgroundResource(android.R.drawable.btn_default_small);

		//������һ���µ����ڰ�ť
		btnYearPrev = new SymbolButton(this,
				SymbolButton.symbol.arrowLeft);
		btnYearPrev.setLayoutParams(new LayoutParams(iSmallButtonWidth,
				android.view.ViewGroup.LayoutParams.WRAP_CONTENT));
		btnYearPrev.setBackgroundResource(android.R.drawable.btn_default_small);

		//������һ���µ����ڰ�ť
		btnYearNext = new SymbolButton(this,
				SymbolButton.symbol.arrowRight);
		btnYearNext.setLayoutParams(new LayoutParams(iSmallButtonWidth,
				android.view.ViewGroup.LayoutParams.WRAP_CONTENT));
		btnYearNext.setBackgroundResource(android.R.drawable.btn_default_small);

		
		//�����м�ĵ������ڰ�ť
		btnMonthToday = createButton("", iSmallButtonWidth,
				android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
		btnMonthToday.setPadding(iHorPadding, btnMonthToday.getPaddingTop(), iHorPadding,
				btnMonthToday.getPaddingBottom());
		btnMonthToday.setBackgroundResource(android.R.drawable.btn_default_small);

		//������һ���µ����ڰ�ť
		btnMonthPrev = new SymbolButton(this,
				SymbolButton.symbol.arrowLeft);
		btnMonthPrev.setLayoutParams(new LayoutParams(iSmallButtonWidth,
				android.view.ViewGroup.LayoutParams.WRAP_CONTENT));
		btnMonthPrev.setBackgroundResource(android.R.drawable.btn_default_small);

		//������һ���µ����ڰ�ť
		btnMonthNext = new SymbolButton(this,
				SymbolButton.symbol.arrowRight);
		btnMonthNext.setLayoutParams(new LayoutParams(iSmallButtonWidth,
				android.view.ViewGroup.LayoutParams.WRAP_CONTENT));
		btnMonthNext.setBackgroundResource(android.R.drawable.btn_default_small);

		
		//����һ��İ�ť���ӵ���¼�
		btnYearPrev.setOnClickListener(new Button.OnClickListener() {
			public void onClick(View arg0) {
				//������һ���°�ť��������ݼ���
				setYearPrevViewItem();
			}
		});
		
		btnYearNext.setOnClickListener(new Button.OnClickListener() {
			public void onClick(View arg0) {
				setYearNextViewItem();
			}
		});
		
		//����һ���µİ�ť���ӵ���¼�
		btnMonthPrev.setOnClickListener(new Button.OnClickListener() {
			public void onClick(View arg0) {
				//������һ���°�ť��������ݼ���
				setPrevViewItem();
			}
		});
		
		btnMonthNext.setOnClickListener(new Button.OnClickListener() {
			public void onClick(View arg0) {
				setNextViewItem();
			}
		});

		layTopControls.setGravity(Gravity.CENTER_HORIZONTAL);
		layTopControls.addView(btnYearPrev);
		layTopControls.addView(btnYearToday);
		layTopControls.addView(btnYearNext);
		layTopControls.addView(btnMonthPrev);
		layTopControls.addView(btnMonthToday);
		layTopControls.addView(btnMonthNext);
	}

	/**
	 * ��ò�����ʽ
	 * @return ���ز�����ͼ
	 */
	private View generateContentView() {
		//���ò���
		LinearLayout layMain = createLayout(LinearLayout.VERTICAL);
		layMain.setPadding(8, 8, 8, 8);
		//������水ť��ʾ����
		LinearLayout layTopControls = createLayout(LinearLayout.HORIZONTAL);

		//����������ʾ����
		layContent = createLayout(LinearLayout.VERTICAL);
		layContent.setPadding(2, 20, 0, 0);
		
		LinearLayout layChoose = createLayout(LinearLayout.HORIZONTAL);
		
		//����ͷ����ť
		generateTopButtons(layTopControls);
		generateCalendar(layContent);
		generateChoose(layChoose);
		layMain.addView(layTopControls);
		layMain.addView(layContent);
		layMain.addView(layChoose);

		tv = new TextView(this);
		layMain.addView(tv);
		return layMain;
	}

	/**
	 * ѡ��ѡ��
	 * @param layChoose
	 */
	private void generateChoose(LinearLayout layChoose) {
		layChoose.setPadding(0, 20, 0, 0);
		Button btnOk = new Button(this);
		btnOk.setText("ȷ��");
		btnOk.setWidth(80);
		btnOk.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
		btnOk.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				// ���Calendarʵ��
				Calendar c = Calendar.getInstance();
				Intent intent = new Intent(CalendarActivity.this,MomoActivity.class);
				intent.putExtra("curDate", c.get(Calendar.YEAR)+"/"+(c.get(Calendar.MONTH)+1)+"/"+c.get(Calendar.DAY_OF_MONTH));
				startActivity(intent);
			}
		});
		Button btnCel = new Button(this);
		btnCel.setText("����");
		btnCel.setWidth(80);
		btnCel.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
		btnCel.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				System.exit(0);
			}
			
		});
		TextView textView = new TextView(this);
		textView.setWidth(145);
		
		layChoose.addView(btnOk);
		layChoose.addView(textView);
		layChoose.addView(btnCel);
	}

	/**
	 * ����е����ݺ���ʾ
	 * @return
	 */
	private View generateCalendarRow() {
		LinearLayout layRow = createLayout(LinearLayout.HORIZONTAL);
		for (int iDay = 0; iDay < 7; iDay++) {
			DateWidgetDayCell dayCell = new DateWidgetDayCell(this,
					43, 43);
			dayCell.setItemClick(mOnDayCellClick);
			days.add(dayCell);
			layRow.addView(dayCell);
		}
		return layRow;
	}

	/**
	 * ���ͷ������
	 * @return
	 */
	private View generateCalendarHeader() {
		LinearLayout layRow = createLayout(LinearLayout.HORIZONTAL);
		for (int iDay = 0; iDay < 7; iDay++) {
			DateWidgetDayHeader day = new DateWidgetDayHeader(this,43, 35);
			final int iWeekDay = DayStyle.getWeekDay(iDay, iFirstDayOfWeek);
			day.setData(iWeekDay);
			layRow.addView(day);
		}
		return layRow;
	}

	/**
	 * �õ�����
	 * @param layContent
	 */
	private void generateCalendar(LinearLayout layContent) {
		layContent.addView(generateCalendarHeader());
		days.clear();
		for (int iRow = 0; iRow < 6; iRow++) {
			layContent.addView(generateCalendarRow());
		}
	}

	/**
	 * ��ÿ�ʼ����
	 * @return ��������
	 */
	private Calendar getCalendarStartDate() {
		calToday.setTimeInMillis(System.currentTimeMillis());
		calToday.setFirstDayOfWeek(iFirstDayOfWeek);

		if (calSelected.getTimeInMillis() == 0) {
			calStartDate.setTimeInMillis(System.currentTimeMillis());
			calStartDate.setFirstDayOfWeek(iFirstDayOfWeek);
		} else {
			calStartDate.setTimeInMillis(calSelected.getTimeInMillis());
			calStartDate.setFirstDayOfWeek(iFirstDayOfWeek);
		}

		UpdateStartDateForMonth();

		return calStartDate;
	}

	/**
	 * ��ʾ�޸ĺ����ҳ��ʾ����
	 * @return
	 */
	private DateWidgetDayCell updateCalendar() {
		DateWidgetDayCell daySelected = null;
		boolean bSelected = false;
		final boolean bIsSelection = (calSelected.getTimeInMillis() != 0);
		final int iSelectedYear = calSelected.get(Calendar.YEAR);
		final int iSelectedMonth = calSelected.get(Calendar.MONTH);
		final int iSelectedDay = calSelected.get(Calendar.DAY_OF_MONTH);
		calCalendar.setTimeInMillis(calStartDate.getTimeInMillis());
		for (int i = 0; i < days.size(); i++) {
			final int iYear = calCalendar.get(Calendar.YEAR);
			final int iMonth = calCalendar.get(Calendar.MONTH);
			final int iDay = calCalendar.get(Calendar.DAY_OF_MONTH);
			final int iDayOfWeek = calCalendar.get(Calendar.DAY_OF_WEEK);
			DateWidgetDayCell dayCell = days.get(i);
			// check today
			boolean bToday = false;
			if (calToday.get(Calendar.YEAR) == iYear)
				if (calToday.get(Calendar.MONTH) == iMonth)
					if (calToday.get(Calendar.DAY_OF_MONTH) == iDay)
						bToday = true;
			// check holiday
			boolean bHoliday = false;
			if ((iDayOfWeek == Calendar.SATURDAY)
					|| (iDayOfWeek == Calendar.SUNDAY))
				bHoliday = true;
			if ((iMonth == Calendar.JANUARY) && (iDay == 1))
				bHoliday = true;

			dayCell.setData(iYear, iMonth, iDay, bToday, bHoliday,
					iMonthViewCurrentMonth);
			bSelected = false;
			if (bIsSelection)
				if ((iSelectedDay == iDay) && (iSelectedMonth == iMonth)
						&& (iSelectedYear == iYear)) {
					bSelected = true;
				}
			dayCell.setSelected(bSelected);
			if (bSelected)
				daySelected = dayCell;
			calCalendar.add(Calendar.DAY_OF_MONTH, 1);
		}
		layContent.invalidate();
		return daySelected;
	}

	/**
	 * �޸��·ݸ��ĺ���ʾ������
	 */
	private void UpdateStartDateForMonth() {
		iMonthViewCurrentMonth = calStartDate.get(Calendar.MONTH);
		iMonthViewCurrentYear = calStartDate.get(Calendar.YEAR);
		calStartDate.set(Calendar.DAY_OF_MONTH, 1);
		
		//�����·ݵ���ʾ
		UpdateCurrentMonthDisplay();
		//
		int iDay = 0;
		int iStartDay = iFirstDayOfWeek;
		if (iStartDay == Calendar.MONDAY) {
			iDay = calStartDate.get(Calendar.DAY_OF_WEEK) - Calendar.MONDAY;
			if (iDay < 0)
				iDay = 6;
		}
		if (iStartDay == Calendar.SUNDAY) {
			iDay = calStartDate.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY;
			if (iDay < 0)
				iDay = 6;
		}
		calStartDate.add(Calendar.DAY_OF_WEEK, -iDay);
	}

	/**
	 * ��ʾ�޸ĺ���µ���ǰ�·�
	 */
	private void UpdateCurrentMonthDisplay() {
		String year = iMonthViewCurrentYear+"";
		String month= (iMonthViewCurrentMonth+ 1)+"";
		btnYearToday.setText(year);
		btnMonthToday.setText(month);
	}
	
	/**
	 * ��һ��İ�ť������ݵĸ���
	 */
	private void setYearPrevViewItem() {
		iMonthViewCurrentYear--;
		calStartDate.set(Calendar.DAY_OF_MONTH, 1);
		calStartDate.set(Calendar.MONTH, iMonthViewCurrentMonth);
		calStartDate.set(Calendar.YEAR, iMonthViewCurrentYear);
		//������ʾ���·ݵ���������
		UpdateStartDateForMonth();
		updateCalendar();

	}

	/**
	 * ��һ���µİ�ť������ݵĸ���
	 */
	private void setPrevViewItem() {
		//������ʾ��������һ
		iMonthViewCurrentMonth--;
		//�ж��Ƿ񷢵������һ����
		if (iMonthViewCurrentMonth == -1) {
			iMonthViewCurrentMonth = 11;
			iMonthViewCurrentYear--;
		}
		//��������ʱ��
		calStartDate.set(Calendar.DAY_OF_MONTH, 1);
		calStartDate.set(Calendar.MONTH, iMonthViewCurrentMonth);
		calStartDate.set(Calendar.YEAR, iMonthViewCurrentYear);
		//������ʾ���·ݵ���������
		UpdateStartDateForMonth();
		updateCalendar();

	}

	/**
	 * ��һ���µĴ���
	 */
	private void setYearNextViewItem() {
		iMonthViewCurrentYear++;
		calStartDate.set(Calendar.DAY_OF_MONTH, 1);
		calStartDate.set(Calendar.MONTH, iMonthViewCurrentMonth);
		calStartDate.set(Calendar.YEAR, iMonthViewCurrentYear);
		UpdateStartDateForMonth();
		updateCalendar();

	}
	/**
	 * ��һ���µĴ���
	 */
	private void setNextViewItem() {
		iMonthViewCurrentMonth++;
		if (iMonthViewCurrentMonth == 12) {
			iMonthViewCurrentMonth = 0;
			iMonthViewCurrentYear++;
		}
		calStartDate.set(Calendar.DAY_OF_MONTH, 1);
		calStartDate.set(Calendar.MONTH, iMonthViewCurrentMonth);
		calStartDate.set(Calendar.YEAR, iMonthViewCurrentYear);
		UpdateStartDateForMonth();
		updateCalendar();

	}

	/**
	 * ���ڵ���¼�
	 */
	private DateWidgetDayCell.OnItemClick mOnDayCellClick = new DateWidgetDayCell.OnItemClick() {
		public void OnClick(DateWidgetDayCell item) {
			Intent intent = new Intent(CalendarActivity.this,MomoActivity.class);
			intent.putExtra("curDate", getDate(item.getDate()));
			startActivity(intent);
			
//			calSelected.setTimeInMillis(item.getDate().getTimeInMillis());
//			item.setSelected(true);
//			updateCalendar();
			
		}
	};
	
	private String getDate(Calendar c){
		int year = c.get(Calendar.YEAR);
		int month = c.get(Calendar.MONTH);
		int day = c.get(Calendar.DAY_OF_MONTH);
		
		String date = year+"/"+(month+1)+"/"+day;
		return date;
	}

}
