package com.calendar.activity;

import java.util.Calendar;
import com.calendar.sqlite.CalendarColumns;
import com.calendar.sqlite.CalendarColumns.CalendarColumn;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.LinearLayout.LayoutParams;

public class CalendarDetailsActivity extends Activity {
	
	// ����¼��Ϣ�б�
	private ListView listView = null;
	// ��������
	private int mYear;
	private int mMonth;
	private int mDay;
	// ����ʱ��
	private int mHour;
	private int mMinute;
	
	private String b;
	
	// ������ʾTextView
	private TextView dateName;
	private TextView dateDesc;
	// ʱ����ʾTextView
	private TextView timeName;
	private TextView timeDesc;
	// ��������TextView
	private TextView contentName;
	private TextView contentDesc;
	// �Ƿ�������
	private String isOrUse = "true";
	// �Ƿ���������
	private String isOrReveal = "true";
	
	private LinearLayout linearLayout ;
	
	private Button btnOk;
	
	// ��ʾ���ڡ�ʱ��Ի�����
	static final int DATE_DIALOG_ID = 0;
	static final int TIME_DIALOG_ID = 1;
	
	// �������ݡ����ڡ�ʱ���ַ���
	private String content;
	private String date1;
	private String time1;
	// ����¼ID
	private int id1;
	// ��ѡ��
	private CheckedTextView ctv1;
	private CheckedTextView ctv2;
	// ���ʲ���ʵ��
	private LayoutInflater li;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		// ���ListView
		listView = new ListView(this);
		// ʵ����LayoutInflater
		li = getLayoutInflater();
		// ����ListView Adapter 
		listView.setAdapter(new ViewAdapter());
		// �ɶ�ѡ
		listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

		// ���Calendarʵ��
		final Calendar c = Calendar.getInstance();
		// ��õ�ǰ���ڡ�ʱ��
//		mYear = c.get(Calendar.YEAR);
//		mMonth = c.get(Calendar.MONTH);
//		mDay = c.get(Calendar.DAY_OF_MONTH);
		mHour = c.get(Calendar.HOUR_OF_DAY);
		mMinute = c.get(Calendar.MINUTE);
		
		// ��Ӧ�б������¼�
		listView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> av, View v, int position,
					long id) {

				switch (position) {
				// �����Ƿ�������
				case 0:
					ctv1 = (CheckedTextView) v;
					if (ctv1.isChecked()) {
						isOrUse = "true";
					} else {
						isOrUse = "false";
					}
					break;
				// ������������
				case 1:
					showDialog(DATE_DIALOG_ID);
					break;
				// ��������ʱ��
				case 2:
					showDialog(TIME_DIALOG_ID);
					break;
				// ������������
				case 3:
					showDialog1("���������ݣ�");
					break;
				// �����Ƿ�����������
				case 4:
					ctv2 = (CheckedTextView) v;
					if (ctv2.isChecked()) {
						isOrReveal = "true";
						setAlarm(false);
					} else {
						isOrReveal = "false";
						setAlarm(false);
					}
					break;
				default:
					break;
				}
			}
		});
		
		
		this.setContentView(listView);
		linearLayout = new LinearLayout(this);
		generateChoose();
		this.addContentView(linearLayout, new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
	}
	
	 /**
	 * ѡ��ѡ��
	 * @param layChoose
	 */
	private void generateChoose() {
		linearLayout.setOrientation(LinearLayout.HORIZONTAL);
		linearLayout.setPadding(8, 377, 0, 0);
		btnOk = new Button(this);
		btnOk.setText("ȷ��");
		btnOk.setWidth(80);
		btnOk.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
		
		btnOk.setOnClickListener(new OnClickListener(){
			public void onClick(View v) {
				saveOrUpdate();
			}
		});
		
		
		Button btnCel = new Button(this);
		btnCel.setText("����");
		btnCel.setWidth(79);
		btnCel.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
		btnCel.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(CalendarDetailsActivity.this,MomoActivity.class);
				intent.putExtra("curDate", dateDesc.getText().toString());
				startActivity(intent);
			}
			
		});
		
		
		TextView textView = new TextView(this);
		textView.setWidth(145);
		
		linearLayout.addView(btnOk);
		linearLayout.addView(textView);
		linearLayout.addView(btnCel);
	}
	
	// ��ʼ������
	private void init() {
		
		Intent intent = this.getIntent();
		Bundle bundle= intent.getBundleExtra("bundle");
		
		b = bundle.getString("b");
		id1 = bundle.getInt("id");
		date1 = bundle.getString("date");
		
		if ("1".equals(b) && 0 != id1) {
			Uri uri = ContentUris.withAppendedId(CalendarColumns.CalendarColumn.CONTENT_URI, id1);
			Cursor cursor = this.getContentResolver().query(uri, MomoActivity.PROJECTION, null, null, null);
			
			if(cursor.moveToNext()){
				id1 = cursor.getInt(0);
				content = cursor.getString(1);
				date1 = cursor.getString(3);
				time1 = cursor.getString(4);
				isOrUse = cursor.getString(5);
				isOrReveal = cursor.getString(6);
				
			}
			if (time1 != null && time1.length() > 0) {
				String[] strs = time1.split(":");
				mHour = Integer.parseInt(strs[0]);
				mMinute = Integer.parseInt(strs[1]);
			}
		}
		
		if (null != date1 && date1.length() > 0) {
			String[] strs = date1.split("/");
			mYear = Integer.parseInt(strs[0]);
			mMonth = Integer.parseInt(strs[1]);
			mDay = Integer.parseInt(strs[2]);
		}

	}
	
	@Override
	protected void onResume() {
		super.onResume();
		// ��ʼ���б�
		init();
	}
	
	// ��ʾ�Ի���
	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		// ��ʾ���ڶԻ���
		case DATE_DIALOG_ID:
			return new DatePickerDialog(this, mDateSetListener, mYear, mMonth,
					mDay);
		// ��ʾʱ��Ի���
		case TIME_DIALOG_ID:
			return new TimePickerDialog(this, mTimeSetListener, mHour, mMinute,
					false);
		}
		return null;
	}
	
	
	class ViewAdapter extends BaseAdapter {
		// �б���ʾ����
		String[] strs = { "�Ƿ���", "����", "ʱ��", "����", "��������" };
		// ����б�����
		@Override
		public int getCount() {
			return strs.length;
		}
		// �����б���
		@Override
		public Object getItem(int position) {
			return position;
		}
		// �����б�ID
		@Override
		public long getItemId(int position) {
			return position;
		}
		// ��õ�ǰ�б�����ͼ
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View v = li.inflate(R.layout.item_row, null);
			switch (position) {
			//�Ƿ�����������¼
			case 0:
				ctv1 = (CheckedTextView) li.inflate(android.R.layout.simple_list_item_multiple_choice,null);
				ctv1.setText(strs[position]);
				if ("true".equals(isOrUse)) {
					ctv1.setChecked(false);
				} else {
					ctv1.setChecked(true);
				}
				return ctv1;
			// ��������
			case 1:
				dateName = (TextView) v.findViewById(R.id.name);
				dateDesc = (TextView) v.findViewById(R.id.desc);
				dateName.setText(strs[position]);
				dateDesc.setText(mYear + "/" + mMonth + "/" + mDay);
				return v;
			// ����ʱ��
			case 2:
				timeName = (TextView) v.findViewById(R.id.name);
				timeDesc = (TextView) v.findViewById(R.id.desc);
				timeName.setText(strs[position]);
				timeDesc.setText(mHour + ":" + mMinute);
				return v;
			// ��������
			case 3:
				contentName = (TextView) v.findViewById(R.id.name);
				contentDesc = (TextView) v.findViewById(R.id.desc);
				contentName.setText(strs[position]);
				contentDesc.setText(content);
				return v;
			// �Ƿ�������ʾ
			case 4:
				ctv2 = (CheckedTextView) li.inflate(android.R.layout.simple_list_item_multiple_choice,null);
				ctv2.setText(strs[position]);
				if ("true".equals(isOrReveal)) {
					ctv2.setChecked(false);
				} else {
					ctv2.setChecked(true);
				}
				return ctv2;
			default:
				break;
			}

			return null;
		}
	}
	
	// ����֪ͨ��ʾ
	private void setAlarm(boolean flag) {
		final String BC_ACTION = "com.calendar.receiver.TaskReceiver";
		// ���AlarmManagerʵ��
		final AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
		// ʵ����Intent
		Intent intent = new Intent();
		// ����Intent action����
		intent.setAction(BC_ACTION);
		intent.putExtra("msg", content);
		// ʵ����PendingIntent
		final PendingIntent pi = PendingIntent.getBroadcast(
				getApplicationContext(), 0, intent, 0);
		// ���ϵͳʱ��
		final long time1 = System.currentTimeMillis();
		Calendar c = Calendar.getInstance();
		c.set(mYear, mMonth, mDay, mHour, mMinute);
		long time2 = c.getTimeInMillis();
		if (flag&&(time2-time1)>0&&"false".equals(isOrUse)){
			am.set(AlarmManager.RTC_WAKEUP, time2, pi);
		}else{
			am.cancel(pi);
		}
	}

	/*
	 * ������ʾ���ڶԻ���
	 */
	private void showDialog1(String msg) {
		View v = li.inflate(R.layout.item_content, null);
		final EditText contentET = (EditText) v.findViewById(R.id.content);
		contentET.setText(content);
		new AlertDialog.Builder(this).setView(v).setMessage(msg).setCancelable(
				false).setPositiveButton("ȷ��",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						content = contentET.getText().toString();
						contentDesc.setText(content);
					}
				}).show();
	}
	// ʱ��ѡ��Ի���
	private TimePickerDialog.OnTimeSetListener mTimeSetListener = 
		new TimePickerDialog.OnTimeSetListener() {
		public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
			mHour = hourOfDay;
			mMinute = minute;
			timeDesc.setText(mHour + ":" + mMinute);
		}
	};
	// ����ѡ��Ի���
	private DatePickerDialog.OnDateSetListener mDateSetListener = 
		new DatePickerDialog.OnDateSetListener() {
		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			mYear = year;
			mMonth = monthOfYear;
			mDay = dayOfMonth;
			dateDesc.setText(mYear + "/" + mMonth + "/" + mDay);
		}
	};
	
	// ������޸ı���¼��Ϣ
	private void saveOrUpdate() {
		
		ContentValues values = new ContentValues();
		values.clear();
        values.put(CalendarColumns.CalendarColumn.CONTENT, contentDesc.getText().toString());
        values.put(CalendarColumns.CalendarColumn.CREATED, "2011-6-28");
        values.put(CalendarColumns.CalendarColumn.DATE, dateDesc.getText().toString());
        values.put(CalendarColumns.CalendarColumn.TIME, timeDesc.getText().toString());
        values.put(CalendarColumns.CalendarColumn.ISORUSE, ctv1.isChecked() ? "true" : "false");
        values.put(CalendarColumns.CalendarColumn.ISORREVEAL, ctv2.isChecked() ? "true":"false");
		
		// �޸�
		if (!"2".equals(b)) {
			Uri uri = ContentUris.withAppendedId(CalendarColumn.CONTENT_URI, id1);
			getContentResolver().update(uri, values, null, null);
		// ����
		} else {
			Uri uri = CalendarColumns.CalendarColumn.CONTENT_URI;
			getContentResolver().insert(uri, values);
		}
		
		Intent intent = new Intent(CalendarDetailsActivity.this,MomoActivity.class);
		intent.putExtra("curDate", dateDesc.getText().toString());
		startActivity(intent);

	}
}
