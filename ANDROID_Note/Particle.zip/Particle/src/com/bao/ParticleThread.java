package com.bao;

import java.util.List;

public class ParticleThread extends Thread {
	
	public ParticleSet ballSet;
	public int time = 100; //����
	public boolean flag; //�߳����б�־
	public int g = 20; //�������ٶ� 200  PIX/S*S

	
	public ParticleThread(ParticleSet ballSet){
		this.ballSet = ballSet;
		flag = true;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(flag){
			
			//ball.nowX = ball.nowX + (int)(ball.nowXSpeed * time /1000);
			//ball.nowY = ball.nowY + (int)(ball.nowYSpeed * time /1000);
			//ball.nowYSpeed = ball.nowYSpeed + g*time/1000;
			List<Particle> particleList = ballSet.getParticleList();
			for(int i=0;i<particleList.size();i++){
				Particle ball = particleList.get(i);
				ball.nowX = ball.nowX + (int)(ball.nowXSpeed * time /1000);
				ball.nowY = ball.nowY + (int)(ball.nowYSpeed * time /1000);
				ball.nowYSpeed = ball.nowYSpeed + g*time/1000;
				
				if(ball.nowY > 320){
					ballSet.removeParticle(ball);
				}
			}
			
			ballSet.addParticleOneTime();
			try {
				Thread.sleep(time);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
