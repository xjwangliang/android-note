package com.bao;

import java.util.Date;
import java.util.List;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;

public class BallView extends SurfaceView implements Callback {
	
	public final static int EDGE = 100;
	
	public final static int EDGE_X = 480;
	
	public final static int EDGE_Y = 320;
	
	public ParticleSet particleSet;
	
	public BallViewThread ballViewThread;
	
	
	Paint paint;
	
	String fps = "FPS:N/A";

	public BallView(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		
		particleSet = new ParticleSet();
		paint = new Paint();
		paint.setColor(Color.WHITE);
		SurfaceHolder holder = getHolder();
		holder.addCallback(this);
		ballViewThread = new BallViewThread(this,holder);
	}

	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
		// TODO Auto-generated method stub
		
	}

	public void surfaceCreated(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		ballViewThread.start();
		particleSet.start();
	}

	public void surfaceDestroyed(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		particleSet.stop();
	}
	
	public void draw(Canvas canvas){
		
		canvas.drawColor(Color.BLACK);
		
		List<Particle> particleList = particleSet.getParticleList();
		//System.out.println("===="+particleList.size());
		for(int i=0;i<particleList.size();i++){
			Particle particle = particleList.get(i);
			
			//System.out.println("nowX"+particle.nowX);
			//System.out.println("nowX"+particle.nowY);
			
			//RectF rectF = new RectF(particle.nowX,particle.nowY,particle.nowX+particle.r * 2,particle.nowY+particle.r * 2);
			
			canvas.drawPoint(particle.nowX, particle.nowY, paint);
		}
		
		canvas.drawText(fps, 100, 100, paint);
		
	}
	
	class BallViewThread extends Thread{
		
		BallView ballView;
		SurfaceHolder surfaceHolder;
		int time = 50;
		boolean flag;
		int count;
		long startTime;
		public BallViewThread(BallView ballView,SurfaceHolder surfaceHolder){
			
			this.ballView = ballView;
			this.surfaceHolder = surfaceHolder;
			flag = true;
			count = 0;
			
		}
		@Override
		public void run() {
			// TODO Auto-generated method stub
			while(flag){
				//System.out.println("========1========");
				if(count % 20 == 0){
					if(count == 0){
						startTime = new Date().getTime();
					}else{
						long time = new Date().getTime() - startTime;
						double v = 20 / (time / 1000);
						ballView.fps = "FPS:"+v;
						startTime = new Date().getTime();
						count = 0;
					}
				}
				Canvas canvas = surfaceHolder.lockCanvas();
				
				
				
				draw(canvas);
				
				surfaceHolder.unlockCanvasAndPost(canvas);
				try {
					Thread.sleep(time);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				count++;
			}
		}
	}
	
	
	
	

}
