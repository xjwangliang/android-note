package com.bao;


public class Particle {
	public int r;
	public int startX;
	public int startY;
	public int nowX;
	public int nowY;
	public float startXSpeed;
	public float startYSpeed;
	public float nowXSpeed;
	public float nowYSpeed;


	public Particle(int r,int startX,int startY,float startXSpeed,float startYSpeed){
		this.r = r;
		this.startX = startX;
		this.startY = startY;
		this.startXSpeed = startXSpeed;
		this.startYSpeed = startYSpeed;
		nowX = startX;
		nowY = startY;
		nowXSpeed = startXSpeed;
		nowYSpeed = startYSpeed;
	}
	

}
