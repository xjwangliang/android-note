package com.bao;

import java.util.ArrayList;
import java.util.List;

public class ParticleSet {
	
	public final static int COUNT = 10;
	
	private List<Particle> particleList;
	
	public ParticleThread ballThread;
	
	public ParticleSet(){
		particleList = new ArrayList<Particle>();
		
		ballThread = new ParticleThread(this);
	}
	
	public List<Particle> getParticleList(){
		return particleList;
	}
	
	public void start(){
		ballThread.start();
	}
	
	public void stop(){
		ballThread.flag = false;
	}
	public void addParticle(){
		
		int r = 1;
		int startX = 0;
		//Math.random();
		int startY = (int)(30 * Math.random());
		float startXSpeed = 20 + (int)(10 * Math.random());
		float startYSpeed = 0;
		Particle particle = new Particle(r,startX,startY,startXSpeed,startYSpeed);
		particleList.add(particle);
	}
	
	public void removeParticle(Particle particle){
		
		particleList.remove(particle);
	}
	
	public void addParticleOneTime(){
		
		for(int i=0;i<COUNT;i++){
			addParticle();
		}
	}

}
